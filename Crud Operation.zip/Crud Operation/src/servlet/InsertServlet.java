package servlet;

import DAO.UserDAOImpl;
import DB.DBConnection;
import entity.UserDtls;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet("/insertServlet")
public class InsertServlet extends javax.servlet.http.HttpServlet {
    protected void doPost(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {



        try {
            String name = request.getParameter("name");
            String author = request.getParameter("author");
            String price = request.getParameter("price");

            System.out.println(name + " " + author + " " + price);
            UserDtls userDtls = new UserDtls(name,author,price);
            UserDAOImpl userDAO = new UserDAOImpl(DBConnection.getConn());
            boolean f = userDAO.insertUser(userDtls);
            HttpSession session = request.getSession();
            if (f){
                session.setAttribute("succMsg" ,"User details insert successfully");
                response.sendRedirect("Insert.jsp");
            }else {
                session.setAttribute("failedMsg" ,"User details not insert..");
                response.sendRedirect("Admin_AddBooks.jsp");

            }

        }catch (Exception e){
            e.printStackTrace();
        }
    }

    protected void doGet(javax.servlet.http.HttpServletRequest request, javax.servlet.http.HttpServletResponse response) throws javax.servlet.ServletException, IOException {

    }
}
