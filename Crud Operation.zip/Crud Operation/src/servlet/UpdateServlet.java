package servlet;

import DAO.UserDAOImpl;
import DB.DBConnection;
import entity.UserDtls;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
@WebServlet("/updateServlet")
public class UpdateServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        try {
            String name = request.getParameter("name");
            String author = request.getParameter("author");
            String price = request.getParameter("price");

            UserDtls userDtls = new UserDtls();
            userDtls.setName(name);
            userDtls.setAuthor(author);
            userDtls.setPrice(price);

            UserDAOImpl dao = new UserDAOImpl(DBConnection.getConn());
            boolean f = dao.updateUser(userDtls);
            HttpSession session = request.getSession();
            if (f){
                session.setAttribute("succMsg","Update Successfully....");
                response.sendRedirect("Table.jsp");
            }else {
                session.setAttribute("failedMsg","Something wrong....");
                response.sendRedirect("Table.jsp");
            }

        }catch (Exception e){
            e.printStackTrace();
        }



    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }
}
