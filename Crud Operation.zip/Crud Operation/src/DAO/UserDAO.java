package DAO;

import entity.UserDtls;

import java.util.List;

public interface UserDAO {
    public abstract boolean insertUser(UserDtls userDtls);

    public abstract List<UserDtls> getAllUser();

    public abstract Boolean updateUser(UserDtls userDtls);

    public abstract  UserDtls getUserByName(String name);

    public abstract boolean deleteUser(String name);

}
