package DAO;

import entity.UserDtls;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDAOImpl implements UserDAO {

    private Connection connection;
    public UserDAOImpl(Connection connection){
        super();
        this.connection = connection;
    }

    @Override
    public boolean insertUser(UserDtls userDtls) {
        boolean f = false;
        try {
            String sql = "insert into user_info(name,author,price) values(?,?,?)";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,userDtls.getName());
            ps.setString(2,userDtls.getAuthor());
            ps.setString(3,userDtls.getPrice());

            int i = ps.executeUpdate();
            if (i==1){
                f=true;
            }


        }catch (Exception e){
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public List<UserDtls> getAllUser() {
        List<UserDtls> list = new ArrayList<>();
        UserDtls userDtls = null;

        try {
            String sql = "select * from user_info";
            PreparedStatement ps = connection.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()){
                userDtls = new UserDtls();
                userDtls.setName(rs.getString(1));
                userDtls.setAuthor(rs.getString(2));
                userDtls.setPrice(rs.getString(3));
                list.add(userDtls);
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Boolean updateUser(UserDtls userDtls) {
        boolean f = false;

        try {
            String sql = "update user_info set   name=? , author=? , price=?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,userDtls.getName());
            ps.setString(2,userDtls.getAuthor());
            ps.setString(3,userDtls.getPrice());

            int i = ps.executeUpdate();
            if (i==1){
                f=true;
            }

        }catch (Exception e){
            e.printStackTrace();
        }
        return f;
    }

    @Override
    public UserDtls getUserByName(String name) {
        UserDtls userDtls = null;

        try {
            String sql = "select * from user_info where name =?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,name);

            ResultSet rs = ps.executeQuery();
            while (rs.next()){

                userDtls = new UserDtls();
                userDtls.setName(rs.getString(1));
                userDtls.setAuthor(rs.getString(2));
                userDtls.setPrice(rs.getString(3));

            }

        }catch (Exception e){

        }
        return userDtls;
    }

    @Override
    public boolean deleteUser(String name) {
        boolean f = false;
        try {
            String sql = "delete from user_info where name = ?";
            PreparedStatement ps = connection.prepareStatement(sql);
            ps.setString(1,name);
            int i = ps.executeUpdate();
            if (i==1){
                f=true;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return f;
    }
}

